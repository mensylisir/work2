#!/bin/bash
gitbook install
gitbook build
cp images/apple-touch-icon-precomposed-152.png _book/gitbook/images
