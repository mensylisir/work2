# Kubernetes社区贡献

如果您想参与 Kubernetes 社区，请先阅读下[Kubernetes Community](https://github.com/kubernetes/community)这个 GitHub Repo中的文档，该文档中包括社区的治理形式、社区成员资格申请、提交 Issue、查找问题和提交 PR 的指导等。

## 参考

- [Kubernetes Community](https://github.com/kubernetes/community)
- [Kubernetes Developer Guide](https://github.com/kubernetes/community/tree/master/contributors/devel)
- [Enhencement Tracking and Backlog](https://github.com/kubernetes/features)
- [Kubernetes 官方网站项目](https://github.com/kubernetes/website)
