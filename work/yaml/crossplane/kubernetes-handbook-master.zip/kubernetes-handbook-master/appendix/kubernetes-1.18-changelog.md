# Kubernetes 1.18 更新日志

## 参考

* [Kubernetes 1.18: Fit & Finish](https://kubernetes.io/blog/2020/03/25/kubernetes-1-18-release-announcement/)

