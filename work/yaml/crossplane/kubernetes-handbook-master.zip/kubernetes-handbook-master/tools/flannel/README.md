# mk-docker-opts.sh

flannel 0.7.1 release中的脚本

See https://github.com/coreos/flannel/releases
