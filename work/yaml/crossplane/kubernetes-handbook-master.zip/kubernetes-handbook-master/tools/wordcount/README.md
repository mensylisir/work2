# 全书字数统计

## 使用说明

首先需要安装`cnworcount`，见：https://github.com/rootsongjc/cnwordcount

在该目录下执行：

```bash
./wordcount
...
usecases/service-mesh.md 1306
usecases/spark-standalone-on-kubernetes.md 285
usecases/understanding-serverless.md 3481
Total 136674
```