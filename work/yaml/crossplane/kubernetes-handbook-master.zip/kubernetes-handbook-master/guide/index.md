# 用户指南

该章节主要记录kubernetes使用过程中的一些配置技巧和操作。

- [配置Pod的liveness和readiness探针](configure-liveness-readiness-probes.md)
- [管理集群中的TLS](managing-tls-in-a-cluster.md)


