# 命令使用

Kubernetes 中的 kubectl 及其他管理命令使用。
