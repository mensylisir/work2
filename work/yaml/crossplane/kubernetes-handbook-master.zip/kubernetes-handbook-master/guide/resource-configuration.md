# 资源配置

Kubernetes 中的各个 Object 的配置指南。
